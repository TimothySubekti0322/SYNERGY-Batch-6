# Instruksi

1.  User klik button add to cart pada list product
2.  Program menampilkan product yang dipilih oleh user
3.  Menampilkan list product yang dipilih di dalam "Your Cart"
4.  User input promo code yang tersedia
5.  Promo code mengandung nilai diskon
6.  Program mengkalkulasi total dari subtotal dan diskon yang dipilih dari promo code
7.  (Nilai Plus) Tambahkan styling boleh menggunakan Bootstrap, Tailwind atau css sendiri.

Keyword:

- getElementById
- getQuerySelectorAll
- getAttribut
